function onSignIn(googleUser) {
    console.log(googleUser);
    const id_token = googleUser.getAuthResponse().id_token;
    const profile = googleUser.getBasicProfile();
    console.log('Id: ' + profile.getId());
    console.log('Name: ' + profile.getName());
    console.log('Image URL: ' + profile.getImageUrl());
    console.log('Email: ' + profile.getEmail());
    console.log('Token-Id: ' + id_token);

    const req = new XMLHttpRequest();
    req.open('POST', 'http://localhost:8080/SSOTokenSignIn');
    req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    req.send('idToken=' + id_token);

}

function signOut() {
    const auth2 = gapi.auth2.getAuthInstance();
    auth2.signOut().then(() => console.log('User signed out.'));
}