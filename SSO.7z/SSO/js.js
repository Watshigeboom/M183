const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();

app.use(express.static("public"));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/verifyCredentials', (req, res) => {

    if (req.body.username == 'username' && req.body.password == 'password') {
        res.sendFile(__dirname + '/public/loginSuccess.html');

    } else {
        res.sendFile(__dirname + '/public/loginFailed.html');
    }
});


app.post('/SSOTokenSignIn', (req, res) => {
    axios.post('https://www.googleapis.com/oauth2/v3/tokeninfo', {id_token: req.body.idToken})
        .then(response => {
            console.log(response);
            res.json({verified: true});
        })
        .catch(e => {
            console.log(e);
            res.json({verified: false});
        })
})

app.listen(8080, () => console.log('server listening on port 8080'));