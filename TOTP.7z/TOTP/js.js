const express = require('express');
const bodyParser = require('body-parser');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const app = express();

app.use(express.static("public"));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

function validateToken(token) {
    return speakeasy.totp.verify({
        secret: 'VERYSECRETSECRET',
        encoding: 'base32',
        token: token
    });
}

app.post('/verifyCredentials', (req, res) => {

    if (req.body.username == 'username' && req.body.password == 'password' && validateToken(req.body.token)) {
        res.sendFile(__dirname + '/public/loginSuccess.html');
    } else {
        res.sendFile(__dirname + '/public/loginFailed.html');
    }
});

app.listen(8080, () => console.log('server listening on port 8080'));

