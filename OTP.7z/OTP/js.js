const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const app = express();

app.use(express.static("public"));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

function sendEmail(res) {
    axios({
        method: 'post',
        url: 'https://api.mailgun.net/v3/sandboxf2cede510f4e476aa76e8e9779d44e9a.mailgun.org/messages',
        params: {from: 'Test User <mailgun@sandboxf2cede510f4e476aa76e8e9779d44e9a.mailgun.org>', to: 'julian288@hotmail.ch', subject: 'Token', text: '!SECRET!'},
        withCredentials: true,
        headers:{Authorization:'Basic '+ Buffer.from('api:'+ '3dd54d02793a2eb3aff9bd1e8c5989a9-49a2671e-4cecd407').toString('base64')}
    })
    .then(response => {
        res.sendFile(__dirname + '/public/token.html');
    })
    .catch(error => {
        res.sendFile(__dirname + '/public/tokenSentFailed.html');
    });
}

function sendSMS(res) {
    axios.post('https://rest.nexmo.com/sms/json', {params: {api_key: '3de7e1f2', api_secret: 'bpduqvUiQn1pO20x', to: '41793694534', from: 'NEXMO', text: '!SECRET!'}})
        .then(response => {
            res.sendFile(__dirname + '/public/token.html');
        })
        .catch(error => {
            res.sendFile(__dirname + '/public/tokenSentFailed.html');
        });
}

app.post('/verifyCredentials', (req, res) => {

    if (req.body.username == 'username' && req.body.password == 'password') {
        ((req.body.twofact == 'email') ? sendEmail : sendSMS)(res);

    } else {
        res.sendFile(__dirname + '/public/loginFailed.html');
    }
});

app.post('/verifyToken', (req, res) => {
    if (req.body.token == '!SECRET!'){
        res.sendFile(__dirname + '/public/loginSuccess.html');
    } 
    else {
        res.sendFile(__dirname + '/public/loginFailed.html');
    }
})

app.listen(8080, () => console.log('server listening on port 8080'));